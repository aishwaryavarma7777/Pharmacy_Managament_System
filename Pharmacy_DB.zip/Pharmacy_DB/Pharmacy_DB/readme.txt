The backup bat file contains the commands to query the Neon Database and send the pg_dump output and store it as a file
To use the backup bat file need to change variables according to your NeonPostGres db credentials
DB_NAME	
DB_USER	
DB_PASSWORD	
DB_HOST	
DB_PORT